###################################
#         ABSCHlUSSPROJEKT        #
# Denis Dordevic, Alexander Grgic #
#       Programmieren in R        #
###################################


library(tidyverse)
library(scales)
library(rlang)

#1. Einlesung der Daten und Erstellung logischer Dimensionsvariablen
overall <- read.csv2("Overall.csv", stringsAsFactors = FALSE)
neurips <- read.csv2("Neurips_D&B.csv", stringsAsFactors = FALSE)
#Erste Zeile entfernen
neurips <- neurips[-1, ]
colnames(neurips)
#Hilfsfunktionen
contains_yes <- function(x) grepl("yes", x, ignore.case = TRUE)
does_not_contain <- function(x, phrase) !grepl(phrase, x, ignore.case = TRUE)

#Logische Dimensionsvariablen für Overall
overall <- overall %>%
  mutate(
    collection_sources_informed = does_not_contain(collection_sources, "collected are not"),
    collection_description_informed = does_not_contain(collection_data_explanation, "does not contain|does not include"),
    recommended_uses_informed = does_not_contain(uses_data_uses, "does not p"),
    annotation_infrastructure_informed = contains_yes(annotation_infrastructure),
    profile_collection_target_informed = contains_yes(collection_target_demographics),
    annotation_validation_informed = contains_yes(annotation_validation_methods),
    speech_context_informed = contains_yes(collection_speakers_demographics),
    social_concerns_informed = contains_yes(uses_biases_bool),
    tested_ml_informed = contains_yes(uses_ml_approach_bool),
    generalization_limits_informed = contains_yes(uses_data_limits),
    collectors_profile_informed = contains_yes(collection_team_demographic),
    annotators_profile_informed = contains_yes(annotation_team_demograaphic), #Tippfehler beachten
    maintenance_policies_informed = contains_yes(authoring_maintenance_policies),
    
    represents_people = grepl("Yes,", uses_represents_people, ignore.case = TRUE),
    concerns_language = !grepl("No", collection_language, ignore.case = TRUE),
    annotation_done = contains_yes(annotation_done)
  )
#Logische Dimensionsvariablen für Neurips
neurips <- neurips %>%
  mutate(
    collection_sources_informed = does_not_contain(collection_sources, "collected are not"),
    collection_description_informed = does_not_contain(collection_explanation, "does not contain|does not include"),
    recommended_uses_informed = does_not_contain(uses_uses, "does not p"),
    annotation_infrastructure_informed = contains_yes(annotation_infrastructure),
    profile_collection_target_informed = contains_yes(collection_target_demographics),
    annotation_validation_informed = contains_yes(annotation_validation_method),
    speech_context_informed = contains_yes(collection_speakers_demographics),
    social_concerns_informed = contains_yes(uses_biases),
    tested_ml_informed = contains_yes(uses_ml_approach_bool),
    generalization_limits_informed = contains_yes(uses_data_limits),
    collectors_profile_informed = contains_yes(collection_team_demographic),
    annotators_profile_informed = contains_yes(annotation_team_demographic),
    maintenance_policies_informed = contains_yes(maintenance_policies),
    
    represents_people = grepl("Yes,", uses_represents_people, ignore.case = TRUE),
    concerns_language = !grepl("No", collection_language, ignore.case = TRUE),
    annotation_done = contains_yes(annotation_done)
  )
#Datensätze kombinieren und Gruppenvariable erstellen
overall$source <- "Data Journal"
neurips$source <- "NeurIPS D&B"
#overall$id sind integer, overall$neurips character
overall <- overall %>% mutate(id = as.character(id))
combined <- bind_rows(overall, neurips) %>%
  mutate(
    group = case_when(
      source == "Data Journal" ~ journal,
      TRUE ~ "NeurIPS D&B"
    )
  )
combined <- combined %>%
  mutate(publication_year = as.integer(publication_year))
#Überprüfen
table(combined$source)
table(combined$group)
glimpse(combined)

#2. Reproduktion der Grafiken

#Figure 1
fig1_data <- combined %>%
  filter(source == "Data Journal") %>%
  count(publication_year, name = "n_articles") %>%
  filter(publication_year >= 2015 & publication_year <= 2023)

ggplot(fig1_data, aes(x = publication_year, y = n_articles)) +
  geom_vline(xintercept = fig1_data$publication_year, color = "grey90") +
  geom_area(fill = "steelblue", alpha = 1) +
  scale_x_continuous(breaks = fig1_data$publication_year) +
  scale_y_continuous(limits = c(0, 800),
                     breaks = seq(0, 800, 100)) +
  theme_classic(base_size = 14) +
  theme(
    panel.grid.major.x = element_line(color = "grey90"),
    panel.grid.major.y = element_blank(),
    panel.grid.minor   = element_blank(),
    
    axis.title     = element_blank(),
    axis.text      = element_text(color = "grey20"),
    axis.ticks     = element_line(color = "grey70")
  )

#Figure 3
fig3_data <- combined %>%
  filter(!is.na(collection_type) & collection_type != "") %>%
  mutate(collection_category = case_when(
    str_detect(tolower(collection_type), "physical data collection") ~ "Physical data collection",
    str_detect(tolower(collection_type), "direct measurments") ~ "Direct measurement",
    str_detect(tolower(collection_type), "manual") ~ "Manual Human Curator",
    str_detect(tolower(collection_type), "software") ~ "Software collection",
    str_detect(tolower(collection_type), "document") ~ "Document analysis",
    str_detect(tolower(collection_type), "secondary") ~ "Secondary Data analysis",
    str_detect(tolower(collection_type), "experiment") ~ "Experiments",
    str_detect(tolower(collection_type), "surveys") ~ "Surveys",
    str_detect(tolower(collection_type), "web scrapp") ~ "Web Scrapping",
    str_detect(tolower(collection_type), "observation") ~ "Observations",
    TRUE ~ "Others"
  ),
  collection_category = factor(
    collection_category,
    levels = rev(c("Physical data collection", "Direct measurement", "Manual Human Curator",
                   "Software collection","Document analysis", "Secondary Data analysis",
                   "Experiments", "Surveys", "Web Scrapping", "Observations", "Others"
                   ))
  )
)%>%
  count(collection_category) %>%
  mutate(perc = n / sum(n))
#Prozente anders, besonders "Others"

ggplot(fig3_data, aes(x = collection_category, y = perc)) +
  geom_col(fill = "steelblue", width = 0.4) +
  geom_text(
    aes(label = scales::percent(perc, accuracy = 1)),
    hjust = -0.1,
    size = 5
    ) +
  scale_y_continuous(
  labels = scales::percent,
  expand = expansion (mult = c(0,0.1)),
  name = "SAMPLE'S PERCENTAGE"
  ) +
  labs(x = NULL) +
  theme_classic(base_size = 14) +
  theme(
    panel.border = element_rect(color = "black", fill = NA),
    panel.background = element_blank(),
    panel.grid.major.x = element_line(color = "grey90"),
    panel.grid.major.y = element_blank(),
    panel.grid.minor = element_blank(),
    
    axis.text.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.text.y = element_text(color = "grey20", size = 12),
    axis.title.x = element_text(vjust = -0.5)
  ) +
  coord_flip()

#Figure 4
fig4_data <- combined %>%
  filter(!is.na(annotation_type) & annotation_type != "") %>%
  mutate(annotation_category = case_when(
    str_detect(tolower(annotation_type), "text entity") ~ "Text Entity Annotation",
    str_detect(tolower(annotation_type), "semantic") ~ "Semantic Segmentation",
    str_detect(tolower(annotation_type), "polygonal") ~ "Polygonal Segmentation",
    str_detect(tolower(annotation_type), "bound") ~ "Bounding Boxes",
    str_detect(tolower(annotation_type), "text categorization") ~ "Text Categorization",
    str_detect(tolower(annotation_type), "genom") ~ "Genomic annotation",
    str_detect(tolower(annotation_type), "temporal") ~ "Temporal annotation",
    str_detect(tolower(annotation_type), "3d") ~ "3D Cuboids",
    str_detect(tolower(annotation_type), "pose") ~ "Pose Estimation",
    str_detect(tolower(annotation_type), "landmark") ~ "Image Landmark",
    TRUE ~ "Others"
  ),
annotation_category = factor(
  annotation_category,
  levels = rev(c(
    "Text Entity Annotation", "Semantic Segmentation", "Polygonal Segmentation",
    "Bounding Boxes", "Text Categorization", "Genomic annotation",
    "Temporal annotation", "3D Cuboids", "Pose Estimation",
    "Image Landmark", "Others"
  ))
)
) %>%
  count(annotation_category) %>%
  mutate(
    perc = n / sum(n))
#Prozente anders
  
ggplot(fig4_data, aes(x = annotation_category, y = perc)) +
  geom_col(fill = "steelblue", width = 0.4) +
  geom_text(
    aes(label = scales::percent(perc, accuracy = 1)),
    hjust = -0.1,
    size = 5
  ) + 
  scale_y_continuous(
    labels = scales::percent,
    expand = expansion (mult = c(0,0.1)),
    name = "SAMPLE'S PERCENTAGE"
  ) +
  labs(x = NULL) +
  theme_classic(base_size = 14) +
  theme(
    panel.border = element_rect(color = "black", fill = NA),
    panel.background = element_blank(),
    panel.grid.major.x = element_line(color = "grey90"),
    panel.grid.major.y = element_blank(),
    panel.grid.minor = element_blank(),
    
    axis.text.x = element_blank(),
    axis.ticks.x = element_blank(),
    axis.text.y = element_text(color = "grey20", size = 12),
    axis.title.x = element_text(vjust = -0.5)
  ) +
  coord_flip()

#Figure 5
fig5_data <- combined %>%
  transmute(
    `Collection sources & infrastructure` = collection_sources_informed,
    `Collection description` = collection_description_informed,
    `Recommended uses` = recommended_uses_informed,
    `Annotation infrastructure` = annotation_infrastructure_informed,
    `Profile collection target` = profile_collection_target_informed & represents_people,
    `Annotation validation` = annotation_validation_informed,
    `Speech context` = speech_context_informed & concerns_language,
    `Social concerns` = social_concerns_informed & represents_people,
    `Tested using an ML approach` = tested_ml_informed,
    `Generalization limits` = generalization_limits_informed,
    `Collectors profile` = collectors_profile_informed,
    `Annotators profile` = annotators_profile_informed,
    `Maintenance policies` = maintenance_policies_informed
  ) %>%
  pivot_longer(everything(), names_to = "dimension", values_to = "informed") %>%
  group_by(dimension) %>%
  summarise(
    perc = mean(informed, na.rm = TRUE),
    count = sum(informed, na.rm = TRUE),
    total = n()
  ) %>%
  mutate(
    dimension = factor(dimension, levels = rev(c(
      "Collection sources & infrastructure",
      "Collection description",
      "Recommended uses",
      "Annotation infrastructure",
      "Profile collection target",
      "Annotation validation",
      "Speech context",
      "Social concerns",
      "Tested using an ML approach",
      "Generalization limits",
      "Collectors profile",
      "Annotators profile",
      "Maintenance policies"
    ))),
    perc_label = label_percent(accuracy=0.01, decimal.mark = ",")(perc)
  )
#Prozente anders

ggplot(fig5_data, aes(x = perc, y = dimension)) +
  geom_col(fill = "steelblue", width = 0.4) +
  geom_text(
    aes(label = label_percent(accuracy = 0.01, decimal.mark = ",")(perc)),
    hjust = -0.1, 
    size = 5
  ) +
  scale_x_continuous(
    expand = expansion(mult = c(0, 0.1)),
    labels = label_percent(accuracy = 0.01, decimal.mark = ","),
    limits = c(0, max(fig5_data$perc) * 1.15)
  ) +
  scale_y_discrete(limits = levels(fig5_data$dimension)) +
  labs(
    x = "PERCENTAGE OF THE SAMPLE", #Rechtschreibfehler "PERCENTATGE" in der Grafik des Artikels
    y = NULL
  ) +
  theme_classic(base_size = 14) +
  theme(
    panel.border         = element_rect(color = "black", fill = NA),
    panel.background     = element_blank(),
    panel.grid.major.x   = element_line(color = "grey90"),
    panel.grid.major.y   = element_blank(),
    panel.grid.minor     = element_blank(),
    axis.text.x          = element_blank(),
    axis.ticks.x        = element_blank(),
    axis.text.y         = element_text(color = "grey20", size = 12),
    axis.title.x        = element_text(vjust = -0.5)
  )

#Figure 6
dimensions <- list(
  `Generalization limits` = list(var = "generalization_limits_informed", subset = NULL),
  `Social concerns` = list(var = "social_concerns_informed", subset = "represents_people == TRUE"),
  `Tested in ML approach` = list(var = "tested_ml_informed", subset = NULL),
  `Profile collection team` = list(var = "collectors_profile_informed", subset = NULL),
  `Profile collection target` = list(var = "profile_collection_target_informed", subset = "represents_people == TRUE"),
  `Speech context in language datasets` = list(var = "speech_context_informed", subset = "concerns_language == TRUE"),
  `Profile annotation team` = list(var = "annotators_profile_informed", subset = "annotation_done == TRUE"),
  `Annotation infrastructure` = list(var = "annotation_infrastructure_informed", subset = "annotation_done == TRUE"),
  `Annotation validation` = list(var = "annotation_validation_informed", subset = "annotation_done == TRUE")
)

# Aggregiere Daten pro Jahr
fig6_data <- data.frame()
for (dim_name in names(dimensions)) {
  for (year in 2015:2023) {
    sub <- overall %>% #nur Data Journals
      filter(publication_year == year)
    #Verwnedung domänenspezifischer Einschränkungen
    #z.B. "Social concerns" nur bei Menschen-bezogenen Datensätzen betrachtet
    if (!is.null(dimensions[[dim_name]]$subset)) {
      sub <- filter(sub, !!rlang::parse_expr(dimensions[[dim_name]]$subset))
    }
    #Prozentberechung für Jahr-Dimension-Paar
    perc <- mean(sub[[dimensions[[dim_name]]$var]], na.rm = TRUE) * 100
    fig6_data <- rbind(fig6_data, data.frame(
      year = year,
      percent = perc,
      dimension = dim_name
    ))
  }
}
dim_order <- c(
  "Generalization limits",
  "Social concerns",
  "Tested in ML approach",
  "Profile collection team",
  "Profile collection target",
  "Speech context in language datasets",
  "Profile annotation team",
  "Annotation infrastructure",
  "Annotation validation"
)
fig6_data$dimension <- factor(fig6_data$dimension, levels = dim_order)

ggplot(fig6_data, aes(x = year, y = percent)) +
  geom_area(fill = "steelblue", alpha = 0.8) +
  facet_wrap(~ dimension, scales = "free", nrow = 3, dir = "h") +
  scale_x_continuous(breaks = 2015:2023) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.05))) +
  labs(
    x = NULL, y = NULL
  ) +
  theme_minimal(base_size = 12) +
  theme(
    strip.text = element_text(face = "bold"),
    panel.grid.minor = element_blank()
  )

#Figure 7
fig7_data <- combined %>%
  filter(journal %in% c("Scientific Data", "Data in Brief")) %>%
  transmute(
    journal,
    `Collection sources & infrastructure` = collection_sources_informed,
    `Collection description` = collection_description_informed,
    `Recommended uses` = recommended_uses_informed,
    `Annotation infrastructure` = annotation_infrastructure_informed & annotation_done,
    `Profile collection target` = profile_collection_target_informed & represents_people,
    `Annotation validation` = annotation_validation_informed & annotation_done,
    `Speech context` = speech_context_informed & concerns_language,
    `Social concerns` = social_concerns_informed & represents_people,
    `Tested using an ML approach` = tested_ml_informed,
    `Generalization limits` = generalization_limits_informed,
    `Collectors profile` = collectors_profile_informed,
    `Annotators profile` = annotators_profile_informed & annotation_done,
    `Maintenance policies` = maintenance_policies_informed
  ) %>%
  pivot_longer(
    cols = -journal,
    names_to = "dimension",
    values_to = "informed"
  ) %>%
  group_by(journal, dimension) %>%
  summarise(
    perc_informed = mean(informed, na.rm = TRUE) * 100,
    .groups = "drop"
  ) %>%
  mutate(
    dimension = factor(dimension, levels = rev(c(
      "Collection sources & infrastructure",
      "Collection description",
      "Recommended uses",
      "Annotation infrastructure",
      "Profile collection target",
      "Annotation validation",
      "Speech context",
      "Social concerns",
      "Tested using an ML approach",
      "Generalization limits",
      "Collectors profile",
      "Annotators profile",
      "Maintenance policies"
    )))
  )

ggplot(fig7_data, aes(x = perc_informed, y = dimension, fill = journal)) +
  geom_vline(xintercept = seq(0, 100, 10), color = "grey90")+
  geom_col(
    position = position_dodge2(width = 0.8, preserve = "single", reverse = FALSE),
    width = 0.6
  ) +
  geom_text(
    aes(label = sprintf("%.2f%%", perc_informed)),
    position = position_dodge2(width = 0.8, preserve = "single", reverse = FALSE),
    hjust = -0.1,
    size = 3
  ) +
  scale_fill_manual(
    values = c("Scientific Data" = "steelblue", "Data in Brief" = "red")
  ) +
  scale_x_continuous(
    limits = c(0, 100),
    expand = expansion(mult = c(0, 0.05)),
    breaks = seq(0, 100, 10),
    labels = NULL
  ) +
  labs(x = "PERCENTAGE OF THE SAMPLE", y = NULL, fill = NULL) + #Rechtschreibfehler "PERCENTATGE" in der Grafik des Artikels
  theme_classic(base_size = 14) +
  theme(
    panel.border        = element_rect(color = "black", fill = NA),
    panel.grid.major.y  = element_blank(),
    panel.grid.minor    = element_blank(),
    
    axis.text.y         = element_text(color = "grey20", size = 11),
    axis.text.x         = element_blank(),
    axis.ticks.x        = element_blank(),
    
    legend.position     = "top",
    legend.direction    = "horizontal",
    legend.justification= "center",
    legend.background   = element_blank(),
    legend.key          = element_blank(),
    legend.text         = element_text(size = 12)
  )

#Figure 9
dimensions <- list(
  `Annotation infrastructure` = list(var = "annotation_infrastructure_informed", subset = "annotation_done == TRUE"),
  `Profile collection target` = list(var = "profile_collection_target_informed", subset = "represents_people == TRUE"),
  `Annotation validation` = list(var = "annotation_validation_informed", subset = "annotation_done == TRUE"),
  `Speech context` = list(var = "speech_context_informed", subset = "concerns_language == TRUE"),
  `Social concerns` = list(var = "social_concerns_informed", subset = "represents_people == TRUE"),
  `Tested using an ML approach` = list(var = "tested_ml_informed", subset = NULL),
  `Generalization limits` = list(var = "generalization_limits_informed", subset = NULL),
  `Collectors profile` = list(var = "collectors_profile_informed", subset = NULL),
  `Annotators profile` = list(var = "annotators_profile_informed", subset = "annotation_done == TRUE"),
  `Maintenance Policies` = list(var = "maintenance_policies_informed", subset = NULL)
)
fig9_data <- data.frame()
# Data Journals (Overall)
for (dim_name in names(dimensions)) {
  sub <- combined %>% 
    filter(source == "Data Journal")
  
  if (!is.null(dimensions[[dim_name]]$subset)) {
    sub <- filter(sub, !!rlang::parse_expr(dimensions[[dim_name]]$subset))
  }
  
  perc <- mean(sub[[dimensions[[dim_name]]$var]], na.rm = TRUE) * 100
  fig9_data <- rbind(fig9_data, data.frame(
    dimension = dim_name,
    group = "Data journals overall",
    percent = perc
  ))
}
# NeurIPS D&B
for (dim_name in names(dimensions)) {
  sub <- combined %>% 
    filter(source == "NeurIPS D&B")
  
  if (!is.null(dimensions[[dim_name]]$subset)) {
    sub <- filter(sub, !!rlang::parse_expr(dimensions[[dim_name]]$subset))
  }
  
  perc <- mean(sub[[dimensions[[dim_name]]$var]], na.rm = TRUE) * 100
  fig9_data <- rbind(fig9_data, data.frame(
    dimension = dim_name,
    group = "NeurIPS D&B datasets",
    percent = perc
  ))
}

dim_order <- c(
  "Annotation infrastructure", "Profile collection target", "Annotation validation",
  "Speech context", "Social concerns", "Tested using an ML approach", "Generalization limits",
  "Collectors profile", "Annotators profile","Maintenance Policies"
)
fig9_data <- fig9_data %>%
  mutate(
    # Sicherstellen, dass Percent numerisch ist (falls es als Character vorliegt)
    percent = as.numeric(percent),
    # Label mit %-Zeichen erstellen (für geom_text)
    label = sprintf("%.2f%%", round(percent, 2))
  )
fig9_data <- fig9_data %>%
  mutate(
    dimension = factor(dimension, levels = dim_order, ordered = TRUE)
  )
#Annotation Validation = 0%
ggplot(fig9_data, aes(x = percent, y = dimension, fill = group)) +
  geom_vline(xintercept = seq(0, 100, 10), color = "grey90") +
  geom_col(
    position = position_dodge2(width = 0.8, preserve = "single", reverse = TRUE),
    width = 0.6
  ) +
  geom_text(aes(label = label),
            position = position_dodge2(width = 0.8, preserve = "single", reverse = TRUE),
            hjust = -0.1, size = 3) +
  scale_fill_manual(
    breaks = c("Data journals overall", "NeurIPS D&B datasets"),
    values = c(
      "Data journals overall" = "steelblue",
      "NeurIPS D&B datasets" = "red"
    )
  ) +
  scale_x_continuous(
    limits = c(0, 100),
    expand = expansion(mult = c(0, 0.05)),
    breaks = seq(0, 100, 10),
    labels = NULL
  ) +
  scale_y_discrete(limits = rev(levels(fig9_data$dimension))) +
  labs(x = "PERCENTAGE OF THE SAMPLE", y = NULL, fill = NULL) + #Rechtschreibfehler "PERCENTATGE" in der Grafik des Artikels
  theme_classic(base_size = 14) +
  theme(
    panel.border        = element_rect(color = "black", fill = NA),
    panel.grid.major.y  = element_blank(),
    panel.grid.minor    = element_blank(),
    
    axis.text.y         = element_text(color = "grey20", size = 11),
    axis.text.x         = element_blank(),
    axis.ticks.x        = element_blank(),
    
    legend.position     = "top",
    legend.direction    = "horizontal",
    legend.justification= "center",
    legend.background   = element_blank(),
    legend.key          = element_blank(),
    legend.text         = element_text(size = 12)
  )
#Annotation validation NeurIPS 0%, wir können den Fehler nicht finden

#3. Testen von Anteilsunterschieden zwischen verschiedenen Gruppen

#Hilfsfunktion
prop_test_helper <- function(arr) {
  apply(arr, 1, function(x) {
    #Extremfälle (0% oder 100% Erfolgsrate)
    if (all(x[, "success"] == 0) || all(x[, "success"] == x[, "total"])) {
      return(list(
        p.value = NA_real_,
        estimate = setNames(x[, "success"] / x[, "total"], rownames(x)),
        conf.int = matrix(NA, nrow = 1, ncol = 2)
      ))
    }
    #Entscheidungskriterien für Testwahl
    total_min <- min(x[, "total"])
    success_min <- min(x[, "success"])
    failure_min <- min(x[, "total"] - x[, "success"])
    
    #Berechne erwartete Häufigkeiten für Chi-Quadrat
    expected_freq <- (sum(x[, "success"]) / sum(x[, "total"])) * x[, "total"]
    
    #Entscheidung: Fisher-Test bei kleinen Stichproben oder kleinen erwarteten Häufigkeiten
    use_fisher <- total_min < 30 || 
      success_min < 5 || 
      failure_min < 5 || 
      any(expected_freq < 5)
    
    if (use_fisher) {
      test_result <- tryCatch(
        {
          #Fisher-Test mit simulierten p-Werten
          fisher.test(
            matrix(c(x[, "success"], x[, "total"] - x[, "success"]), 
                   ncol = nrow(x)),
            simulate.p.value = TRUE,
            B = 100000
          )
        },
        error = function(e) {
          #Rückfall auf exakten Test bei Fehlern
          tryCatch(
            fisher.test(
              matrix(c(x[, "success"], x[, "total"] - x[, "success"]), 
                     ncol = nrow(x))
            ),
            error = function(e2) {
              warning("Fisher-Test fehlgeschlagen: ", e2$message)
              NULL
            }
          )
        }
      )
    } else {
      test_result <- tryCatch(
        #Chi² Test für große Stichproben
        prop.test(x[, "success"], x[, "total"], correct = FALSE),
        error = function(e) {
          warning("Chi-Quadrat-Test fehlgeschlagen: ", e$message)
          NULL
        }
      )
    }
    #Ergebnisrückgabe
    if (is.null(test_result)) {
      list(
        p.value = NA_real_,
        estimate = setNames(x[, "success"] / x[, "total"], rownames(x)),
        conf.int = matrix(NA, nrow = 1, ncol = 2)
      )
    } else {
      list(
        p.value = test_result$p.value,
        estimate = setNames(x[, "success"] / x[, "total"], rownames(x)),
        conf.int = if (!is.null(test_result$conf.int)) {
          matrix(test_result$conf.int, nrow = 1, ncol = 2)
        } else {
          matrix(NA, nrow = 1, ncol = 2)
        }
      )
    }
  })
}

#Testfunktion für Figure 7, Scientific Data vs. Data in Brief
fig7_tests <- function(df) {
  flags <- c(
    "collection_sources_informed",
    "collection_description_informed",
    "recommended_uses_informed",
    "annotation_infrastructure_informed",
    "profile_collection_target_informed",
    "annotation_validation_informed",
    "speech_context_informed",
    "social_concerns_informed",
    "tested_ml_informed",
    "generalization_limits_informed",
    "collectors_profile_informed",
    "annotators_profile_informed",
    "maintenance_policies_informed"
  )
  #Einschränkungen
  restrictions <- list(
    profile_collection_target_informed = expr(represents_people),
    social_concerns_informed = expr(represents_people),
    speech_context_informed = expr(concerns_language),
    annotators_profile_informed = expr(annotation_done),
    annotation_validation_informed = expr(annotation_done),
    annotation_infrastructure_informed = expr(annotation_done)
  )
  #3D Array [Dimension, Journal, Metrik]
  arr <- array(
    dim = c(length(flags), 2, 2),
    dimnames = list(
      flags,
      c("Scientific Data", "Data in Brief"),
      c("success", "total")
    )
  )
  for (i in seq_along(flags)) {
    f <- flags[i]
    sub <- df %>% 
      filter(journal %in% c("Scientific Data", "Data in Brief"))
    #Verwendung von Einschränkungen wenn nötig, z.B. bei  "Social concerns" nur Menschen-bezogene DS
    if (f %in% names(restrictions)) {
      sub <- sub %>% filter(!!restrictions[[f]])
    }
    #Erfolge, Gesamtzahl pro Journal
    counts <- sub %>%
      group_by(journal) %>%
      summarise(
        success = sum(.data[[f]], na.rm = TRUE),
        total = n(),
        .groups = "drop"
      ) %>%
      arrange(match(journal, c("Scientific Data", "Data in Brief")))
    #Array füllen
    arr[i, , "success"] <- counts$success
    arr[i, , "total"] <- counts$total
  }
  
  prop_test_helper(arr)
}

#Testfunktion für Figure 9, Data Journals vs. NeurIPS
fig9_tests <- function(df) {
  flags <- c(
    "collection_sources_informed",
    "collection_description_informed",
    "recommended_uses_informed",
    "annotation_infrastructure_informed",
    "profile_collection_target_informed",
    "annotation_validation_informed",
    "speech_context_informed",
    "social_concerns_informed",
    "tested_ml_informed",
    "generalization_limits_informed",
    "collectors_profile_informed",
    "annotators_profile_informed",
    "maintenance_policies_informed"
  )
  restrictions <- list(
    profile_collection_target_informed = expr(represents_people),
    social_concerns_informed = expr(represents_people),
    speech_context_informed = expr(concerns_language),
    annotators_profile_informed = expr(annotation_done),
    annotation_validation_informed = expr(annotation_done),
    annotation_infrastructure_informed = expr(annotation_done)
  )
  #3D Array [Dimension, Source, Metrik]
  arr <- array(
    dim = c(length(flags), 2, 2),
    dimnames = list(
      flags,
      c("Data Journal", "NeurIPS D&B"),
      c("success", "total")
    )
  )
  for (i in seq_along(flags)) {
    f <- flags[i]
    sub <- df %>% 
      filter(source %in% c("Data Journal", "NeurIPS D&B"))
    
    if (f %in% names(restrictions)) {
      sub <- sub %>% filter(!!restrictions[[f]])
    }
    
    counts <- sub %>%
      group_by(source) %>%
      summarise(
        success = sum(.data[[f]], na.rm = TRUE),
        total = n(),
        .groups = "drop"
      ) %>%
      arrange(match(source, c("Data Journal", "NeurIPS D&B")))
    #Array füllen
    arr[i, , "success"] <- counts$success
    arr[i, , "total"] <- counts$total
  }
  
  prop_test_helper(arr)
}
#Testfunktion für Figure 6: Zeitliche Entwicklung
fig6_tests <- function(df) {
  #Dimensionen mit zeitlichem Trend
  flags <- c(
    "tested_ml_informed",
    "social_concerns_informed",
    "maintenance_policies_informed"
  )
  restrictions <- list(
    social_concerns_informed = expr(represents_people), #Nur Menschen-bezogene DS
    maintenance_policies_informed = expr(TRUE)  #Keine Einschränkung
  )
  #Aggregiere Daten pro Jahr
  summary_df <- df %>%
    filter(source == "Data Journal", !is.na(publication_year)) %>%
    mutate(year = as.integer(publication_year)) %>%
    filter(year >= 2015, year <= 2023) %>%
    group_by(year) %>%
    filter(n() >= 5) %>%  #Nur Jahre mit mind. 5 Beobachtungen
    summarise(
      tested_ml = sum(tested_ml_informed, na.rm = TRUE),
      total_ml = n(),
      social_concerns = sum(
        social_concerns_informed & represents_people, na.rm = TRUE
      ),
      total_social = n(),
      maintenance = sum(maintenance_policies_informed, na.rm = TRUE),
      total_maintenance = n(),
      .groups = "drop"
    )
  if(nrow(summary_df) == 0){
    return(NULL)
  }
  #3D Array [Dimension, Jahr, Metrik]
  arr <- array(
    dim = c(3, nrow(summary_df), 2),
    dimnames = list(
      flags,
      as.character(summary_df$year),
      c("success", "total")
    )
  )
  #Array füllen
  for (i in seq_along(summary_df$year)) {
    arr["tested_ml_informed", i, ] <- c(
      summary_df$tested_ml[i],
      summary_df$total_ml[i]
    )
    arr["social_concerns_informed", i, ] <- c(
      summary_df$social_concerns[i],
      summary_df$total_social[i]
    )
    arr["maintenance_policies_informed", i, ] <- c(
      summary_df$maintenance[i],
      summary_df$total_maintenance[i]
    )
  }
  prop_test_helper(arr)
}

#Funktion für tabellarische Extraktion der Ergebnisse
extract_test_results <- function(test_results) {
  map_dfr(names(test_results), function(dim_name){
    res <- test_results[[dim_name]]
    #Schätzwerte als String
    estimate_str <- if (!is.null(res$estimate)){
      paste( names(res$estimate), round(res$estimate, 4), sep = " = ",
             collapse = "; ")
    } else{
      NA_character_
    }
    #Konfidenzintervalle
    conf_low <- if (!is.null(res$conf.int)) res$conf.int[1,1] else NA_real_
    conf_high <- if (!is.null(res$conf.int)) res$conf.int[1,2] else NA_real_
    #Rückgabe als Ergebnistabelle
    tibble( dimension = dim_name,
            p_value = if (!is.null(res$p.value)) res$p.value else NA_real_,
            estimates = estimate_str,
            conf_low = round(conf_low, 4),
            conf_high = round(conf_high, 4)
    )
  })
}

#Tests durchführen und Ergebnisse speichern
res7 <- fig7_tests(combined)
res9 <- fig9_tests(combined)
res6 <- fig6_tests(combined)
#Ergebnisse aufbereiten, Signifikanz markieren
fig9_results <- extract_test_results(res9) %>%
  mutate(
    significance = case_when(
      p_value < 0.001 ~ "***",
      p_value < 0.01 ~ "**",
      p_value < 0.05 ~ "*",
      TRUE ~ ""
    )
  )
fig7_results <- extract_test_results(res7) %>%
  mutate(
    significance = case_when(
      p_value < 0.001 ~ "***",
      p_value < 0.01 ~ "**",
      p_value < 0.05 ~ "*",
      TRUE ~ ""
    )
  )
fig6_results <- extract_test_results(res6) %>%
  mutate(
    significance = case_when(
      p_value < 0.001 ~ "***",
      p_value < 0.01 ~ "**",
      p_value < 0.05 ~ "*",
      TRUE ~ ""
    )
  )
write_csv(fig9_results, "figure9_test_results.csv")
write_csv(fig7_results, "figure7_test_results.csv")
write_csv(fig6_results, "figure6_test_results.csv")
